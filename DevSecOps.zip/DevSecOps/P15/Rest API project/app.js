const express = require('express');  // import the express package
const app = express();  // creates an express application

const productRoutes = require('./api/routes/products');
const orderRoutes = require('./api/routes/orders');

// Backend middlware process to handle request and issue response
// app.use((req, res, next) => { res.status(200).json({message: 'Request received!'  }); });

app.use('/products', productRoutes);  // forward requests to product routes
app.use('/orders', orderRoutes);      // forward requests to order routes

module.exports = app;