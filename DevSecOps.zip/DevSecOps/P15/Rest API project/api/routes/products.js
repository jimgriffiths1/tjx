const express = require('express');
const router = express.Router();

// Handler for product GET requests
router.get('/', (req, res, next) =>{
    res.status(200).json({
        message: 'Handling GET requests to /products'
    })
} ) 

// Handler for product POST requests
router.post('/', (req, res, next) =>{
    res.status(201).json({
        message: 'Handling POST requests to /products'
    })
} ) 

// Handler for product ID requests
router.get('/:productId', (req, res, next) => {
    const id = req.params.productId;
    if (id == 'special') {
        res.status(200).json({
            message: 'Special ID handled',
            id: id
        });
     } else {
         res.status(200).json({
            message: 'You passed an ID'
        });
    }
});

// Handler for Patch requests
router.patch('/:productId', (req, res, next) => {
    res.status(200).json({
        message: 'Updated product'
        });
});

// Handler for Delete requests
router.delete('/:productId', (req, res, next) => {
    res.status(200).json({
        message: 'Delete product'
        });
});


module.exports = router;