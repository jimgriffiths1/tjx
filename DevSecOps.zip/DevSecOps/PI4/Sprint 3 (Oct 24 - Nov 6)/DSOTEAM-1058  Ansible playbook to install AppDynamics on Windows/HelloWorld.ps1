$strString = "Hello World"
write-host $strString