const http = require('http');    // import http package from node.js
const app = require('./app.js'); // import the express app we defined in app.js 

const port = process.env.PORT || 3000;  // use PORT env var if defined

const server = http.createServer(app);  //create a server using the express app as its handler


server.listen(port, function(error) {
    if (error) {
        console.log('Something went wrong', error)
    } else {
        console.log('Server is listening on port ' + port)
    }
})