#!/bin/bash
######################################################################################################
# This script: Creates a text file containing OS info for each server in input file.
#              Creates a text file containing any server error encountered.
#              Skips any server (line item) that is commented with #
#              Uses command: 'uname -v -r' to get the AIX version & release info.
#
#   Usage: host_os_info.sh <list_of_servers> 
#
#   Future enhancements:
#    1. When error encountered, avoid having to execute the failed command again just to capture the error output.
#    2. Some servers take a full minute for login to timeout.  Reduce this wait time to ~10 seconds.
#    3. Detect when login not valid (password prompt comes to screen). Intercept this, log to error file and proceed to next server. 
#
# Last modified: Wed Jul 23 13:09:25 EDT 2019
######################################################################################################
export ID=`whoami`
export BASE_DIR=/tmp/$ID
export LOG_DIR="$BASE_DIR/log"
export dt_stamp=`date +%m%d%y%H%M`
export output_file=$LOG_DIR/os_version_info_$dt_stamp
export error_file=$LOG_DIR/connection_errors_$dt_stamp
export host_names_input_file=$1


if [ ! -d "$LOG_DIR" ]; then
    mkdir $LOG_DIR 2>&1 >/dev/null
fi

touch $output_file 2>&1 >/dev/null  # create output file if not present
touch $error_file 2>&1 >/dev/null   # create error file if not present

echo -e "\n OS & version info logged to: $output_file "
echo -e "\n Connection errors logged to: $error_file "

while read -r eachline; do
 
	server=$eachline
	
	skip_msg="skipping commented server: $server"
	
    if [[ $server == \#* ]] # skip any commented server
	then 
	   echo -e $skip_msg
 	   continue 
	fi
    		
	echo -e "\nConnecting to: $server \n"	
		
	version=`ssh -n $ID@$server uname -v`
	release=`ssh -n $ID@$server uname -r`
	os_info=`echo -n $server; echo -n ": AIX "; echo -n $version; echo -n "."; echo $release`
	
		 	
    if [ $? -ne 0 ] 
	then
	   echo -e "\nCommand failed.  Proceeding to next server."
 	   ssh -n $ID@$server uname -n 2>>$error_file  # re-execute failed command to capture error msg
 	   os_info=""
	   server=""
       continue
	fi
      
 	
	echo -e $os_info   # output to screen
	
 	echo -e $os_info >> $output_file  # output to file

done <$host_names_input_file


echo -e "\n check this log: $output_file "
echo -e "\n `date '+%Y-%m-%d %H:%M:%S'` : At end of $0"

exit 0
