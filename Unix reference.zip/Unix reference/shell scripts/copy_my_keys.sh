#!/bin/bash

######################################################################################################
# This script: Copies user's public SSH key to servers in the feeder file (arg 1)
#               
# Note:  The script prompts the user for their password and then pipes it in for each ssh cmd.     
#        This works great except for some servers.  If it fails, it prompts the user to 
#        enter the password manually.  The cause is unknown.  It is probably due to older OSs.
#
#   Usage: copy_my_keys server_file
#
# Last modified: July 29, 2017
######################################################################################################
export myid=`whoami`
export server_names_input_file=$1

read -p "Enter SSH password: " -s password
echo    # force new line after password prompt

for server in `cat $server_names_input_file`
do
echo $server
echo $password | ssh-copy-id -i ~/.ssh/id_rsa.pub $myid@$server
echo
done

exit 0
