#!/bin/bash

######################################################################################################
# This script: Executes a command for each item in the supplied feeder file (arg 1)
#               
#
######################################################################################################

for item in `cat feeder_file`
do
echo $item
some command such as: ssh-copy-id -i ~/.ssh/id_rsa.pub jam01370@$item
echo
done
