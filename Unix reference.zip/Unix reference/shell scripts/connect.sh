#!/bin/bash
######################################################################################################
# This script: 
#
#
#   Usage: 
#
#   
######################################################################################################
export ID=`whoami`
export BASE_DIR=/tmp/$ID
export LOG_DIR="$BASE_DIR/log"
export dt_stamp=`date +%m%d%y%H%M`
export output_file=$LOG_DIR/os_version_info_$dt_stamp
export error_file=$LOG_DIR/connection_errors_$dt_stamp
export host_names_input_file=$1


if [ ! -d "$LOG_DIR" ]; then
    mkdir $LOG_DIR 2>&1 >/dev/null
fi

touch $output_file 2>&1 >/dev/null  # create output file if not present
touch $error_file 2>&1 >/dev/null   # create error file if not present

echo -e "\n OS & version info logged to: $output_file "
echo -e "\n Connection errors logged to: $error_file "

while read -r eachline; do
 
	server=$eachline
	
	skip_msg="skipping commented server: $server"
	
    if [[ $server == \#* ]] # skip any commented server
	then 
	   echo -e $skip_msg
 	   continue 
	fi
    		
	echo -e "\nConnecting to: $server \n"	
	
	cmd_out=`ssh -n $ID@$server`
	
    echo "Cmd output: $cmd_out"
	
	if [[ $cmd_out == '* password:*' ]];
    then
       echo "Command prompted for password"
    else
       echo "Command responded with something else."
    fi
		
		 	
#    if [ $? -ne 0 ] 
#	then
#	   echo -e "\nCommand failed.  Proceeding to next server."
#	   continue
#	fi
      
     	
#	echo -e $os_info   # output to screen
# 	echo -e $os_info >> $output_file  # output to file

done <$host_names_input_file



echo -e "\n check this log: $output_file "
echo -e "\n `date '+%Y-%m-%d %H:%M:%S'` : At end of $0"

exit 0
